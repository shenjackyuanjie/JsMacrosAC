
class AutoCompleteSuggestion(Object, ):

    startIndex: int = None
    suggestion: str = None
    displayText: str = None


    def __init__(startIndex: int, suggestion: str, ):
        pass



    pass
