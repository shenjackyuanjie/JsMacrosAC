
class AutoCompleteSuggestor(Object, ):



    def __init__(language: str, ):
        pass


    def getSuggestions(self, start: str, ) -> list:
        pass


    pass
