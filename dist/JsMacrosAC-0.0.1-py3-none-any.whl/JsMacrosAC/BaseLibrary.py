
class BaseLibrary(Object, ):



    def __init__():
        pass



    pass
