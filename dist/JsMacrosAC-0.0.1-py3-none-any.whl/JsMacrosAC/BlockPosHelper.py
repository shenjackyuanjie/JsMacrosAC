from .BaseHelper import *

class BlockPosHelper(BaseHelper, ):



    def __init__(b: BlockPos, ):
        pass


    def getX(self, ) -> int:
        pass

    def getY(self, ) -> int:
        pass

    def getZ(self, ) -> int:
        pass

    def toString(self, ) -> str:
        pass


    pass
