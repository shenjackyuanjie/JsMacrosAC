from .BaseHelper import *

class CommandContextHelper(BaseHelper, ):



    def __init__(base: CommandContext, ):
        pass


    def getArg(self, name: str, ) -> Object:
        pass

    def getChild(self, ) -> self:
        pass

    def getRange(self, ) -> StringRange:
        pass

    def getInput(self, ) -> str:
        pass


    pass
