from .IEventListener import *
from .ContextContainer import *

class ContextLockWatchdog(Object, ):



    def __init__():
        pass


    def startWatchdog(self, lock: ContextContainer, watched: Thread, listener: IEventListener, maxTime: long, ) -> None:
        pass


    pass
