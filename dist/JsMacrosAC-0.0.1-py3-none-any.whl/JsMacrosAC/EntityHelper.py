from .Pos3D import *
from .NBTElementHelper import *
from .BaseHelper import *

class EntityHelper(BaseHelper, ):



    def __init__(e: T, ):
        pass


    def getPos(self, ) -> Pos3D:
        pass

    def getX(self, ) -> float:
        pass

    def getY(self, ) -> float:
        pass

    def getZ(self, ) -> float:
        pass

    def getEyeHeight(self, ) -> float:
        pass

    def getPitch(self, ) -> float:
        pass

    def getYaw(self, ) -> float:
        pass

    def getName(self, ) -> str:
        pass

    def getType(self, ) -> str:
        pass

    def isGlowing(self, ) -> bool:
        pass

    def isInLava(self, ) -> bool:
        pass

    def isOnFire(self, ) -> bool:
        pass

    def getVehicle(self, ) -> self:
        pass

    def getPassengers(self, ) -> list:
        pass

    def getNBT(self, ) -> NBTElementHelper:
        pass

    def setGlowing(self, val: bool, ) -> self:
        pass

    def isAlive(self, ) -> bool:
        pass

    def toString(self, ) -> str:
        pass

    def create(self, e: Entity, ) -> self:
        pass


    pass
