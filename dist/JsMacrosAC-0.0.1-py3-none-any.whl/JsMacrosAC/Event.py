
class Event(none, Annotation):



    def value(self, ) -> str:
        pass

    def oldName(self, ) -> str:
        pass


    pass
