from .BaseEvent import *

class EventChunkUnload(Object, BaseEvent):

    x: int = None
    z: int = None


    def __init__(x: int, z: int, ):
        pass


    def toString(self, ) -> str:
        pass


    pass
