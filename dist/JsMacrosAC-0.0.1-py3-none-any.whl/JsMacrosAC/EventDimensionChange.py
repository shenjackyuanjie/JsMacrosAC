from .BaseEvent import *

class EventDimensionChange(Object, BaseEvent):

    dimension: str = None


    def __init__(dimension: str, ):
        pass


    def toString(self, ) -> str:
        pass


    pass
