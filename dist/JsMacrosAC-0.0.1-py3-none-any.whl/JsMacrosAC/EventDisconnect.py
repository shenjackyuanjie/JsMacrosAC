from .BaseEvent import *

class EventDisconnect(Object, BaseEvent):



    def __init__():
        pass


    def toString(self, ) -> str:
        pass


    pass
