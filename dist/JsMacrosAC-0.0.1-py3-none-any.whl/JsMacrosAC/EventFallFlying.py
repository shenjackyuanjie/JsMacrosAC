from .BaseEvent import *

class EventFallFlying(Object, BaseEvent):

    state: bool = None


    def __init__(state: bool, ):
        pass


    def toString(self, ) -> str:
        pass


    pass
