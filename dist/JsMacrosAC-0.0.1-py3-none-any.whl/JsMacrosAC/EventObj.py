from .Button import *

class EventObj(Object, ):



    def __init__(event: str, btn: Button, ):
        pass



    pass
