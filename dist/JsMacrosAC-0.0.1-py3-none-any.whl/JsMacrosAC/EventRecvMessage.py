from .BaseEvent import *
from .TextHelper import *

class EventRecvMessage(Object, BaseEvent):

    text: TextHelper = None


    def __init__(message: str, ):
        pass


    def toString(self, ) -> str:
        pass


    pass
