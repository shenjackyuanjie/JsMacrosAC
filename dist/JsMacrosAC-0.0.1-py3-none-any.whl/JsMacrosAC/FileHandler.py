
class FileHandler(Object, ):



    def __init__(path: str, ):
        pass


    def write(self, s: str, ) -> self:
        pass

    def write(self, b: byte, ) -> self:
        pass

    def read(self, ) -> str:
        pass

    def readBytes(self, ) -> byte:
        pass

    def append(self, s: str, ) -> self:
        pass

    def append(self, b: byte, ) -> self:
        pass

    def getFile(self, ) -> File:
        pass

    def toString(self, ) -> str:
        pass


    pass
