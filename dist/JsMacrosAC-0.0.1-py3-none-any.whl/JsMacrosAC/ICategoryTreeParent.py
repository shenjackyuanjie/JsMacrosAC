
class ICategoryTreeParent():



    def selectCategory(self, category: str, ) -> None:
        pass


    pass
