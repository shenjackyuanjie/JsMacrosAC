from .IContainerParent import *

class ICategoryTreeParent(none, IContainerParent):



    def selectCategory(self, category: str, ) -> None:
        pass


    pass
