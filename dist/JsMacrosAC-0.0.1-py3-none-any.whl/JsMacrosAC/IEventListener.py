from .ContextContainer import *
from .BaseEvent import *

class IEventListener(none, ):



    def trigger(self, event: BaseEvent, ) -> ContextContainer:
        pass


    pass
