
class IFontManager():



    def getFontList(self, ) -> list:
        pass


    pass
