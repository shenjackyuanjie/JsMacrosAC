
class IHorseScreen():



    def jsmacros_getEntity(self, ) -> Entity:
        pass


    pass
