
class IInventory():



    def jsmacros_getSlotUnder(self, x: float, y: float, ) -> Slot:
        pass


    pass
