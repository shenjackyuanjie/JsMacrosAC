
class ILoomScreen(none, ):



    def jsmacros_canApplyDyePattern(self, ) -> bool:
        pass


    pass
