
class IMerchantScreen(none, ):



    def jsmacros_selectIndex(self, index: int, ) -> None:
        pass


    pass
