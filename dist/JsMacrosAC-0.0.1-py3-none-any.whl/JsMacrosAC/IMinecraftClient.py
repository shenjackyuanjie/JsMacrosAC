
class IMinecraftClient():



    def getFontManager(self, ) -> FontManager:
        pass


    pass
