
class IPlayerListHud():



    def getHeader(self, ) -> str:
        pass

    def getFooter(self, ) -> str:
        pass


    pass
