
class IPlayerListHud(none, ):



    def jsmacros_getHeader(self, ) -> str:
        pass

    def jsmacros_getFooter(self, ) -> str:
        pass


    pass
