
class IRecipeBookResults():



    def getResultCollections(self, ) -> list:
        pass


    pass
