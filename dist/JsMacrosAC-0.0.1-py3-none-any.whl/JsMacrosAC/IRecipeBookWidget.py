
class IRecipeBookWidget():



    def getResults(self, ) -> RecipeBookResults:
        pass

    def isSearching(self, ) -> bool:
        pass

    def refreshResultList(self, ) -> None:
        pass


    pass
