
class ISignEditScreen(none, ):



    def jsmacros_setLine(self, line: int, text: str, ) -> None:
        pass


    pass
