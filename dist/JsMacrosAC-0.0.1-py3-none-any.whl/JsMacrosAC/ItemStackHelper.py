from .BaseHelper import *
from .NBTElementHelper import *

class ItemStackHelper(BaseHelper, ):



    def __init__(i: ItemStack, ):
        pass


    def setDamage(self, damage: int, ) -> self:
        pass

    def isDamageable(self, ) -> bool:
        pass

    def isEnchantable(self, ) -> bool:
        pass

    def getDamage(self, ) -> int:
        pass

    def getMaxDamage(self, ) -> int:
        pass

    def getDefaultName(self, ) -> str:
        pass

    def getName(self, ) -> str:
        pass

    def getCount(self, ) -> int:
        pass

    def getMaxCount(self, ) -> int:
        pass

    def getNBT(self, ) -> NBTElementHelper:
        pass

    def getCreativeTab(self, ) -> str:
        pass

    def getItemID(self, ) -> str:
        pass

    def isEmpty(self, ) -> bool:
        pass

    def toString(self, ) -> str:
        pass

    def equals(self, ish: self, ) -> bool:
        pass

    def equals(self, is: ItemStack, ) -> bool:
        pass

    def isItemEqual(self, ish: self, ) -> bool:
        pass

    def isItemEqual(self, is: ItemStack, ) -> bool:
        pass

    def isItemEqualIgnoreDamage(self, ish: self, ) -> bool:
        pass

    def isItemEqualIgnoreDamage(self, is: ItemStack, ) -> bool:
        pass

    def isNBTEqual(self, ish: self, ) -> bool:
        pass

    def isNBTEqual(self, is: ItemStack, ) -> bool:
        pass

    def copy(self, ) -> self:
        pass


    pass
