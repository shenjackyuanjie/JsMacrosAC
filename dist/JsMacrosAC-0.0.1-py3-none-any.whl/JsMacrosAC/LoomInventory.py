from .Inventory import *

class LoomInventory(Inventory, ):



    def selectPatternName(self, name: str, ) -> bool:
        pass

    def selectPatternId(self, id: str, ) -> bool:
        pass

    def selectPattern(self, index: int, ) -> bool:
        pass


    pass
