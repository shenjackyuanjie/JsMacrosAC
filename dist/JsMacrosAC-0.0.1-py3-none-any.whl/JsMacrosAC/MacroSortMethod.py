
class MacroSortMethod(Enum, ):

    Enabled: self = None
    TriggerName: self = None
    FileName: self = None


    def values(self, ) -> self:
        pass

    def valueOf(self, name: str, ) -> self:
        pass


    pass
