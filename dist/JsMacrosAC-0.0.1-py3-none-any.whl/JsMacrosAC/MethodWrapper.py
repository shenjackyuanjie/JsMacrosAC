
class MethodWrapper(Object, Consumer):



    def __init__():
        pass


    def accept(self, t: T, ) -> None:
        pass

    def accept(self, t: T, u: U, ) -> None:
        pass

    def apply(self, t: T, ) -> R:
        pass

    def apply(self, t: T, u: U, ) -> R:
        pass

    def test(self, t: T, ) -> bool:
        pass

    def test(self, t: T, u: U, ) -> bool:
        pass

    def preventSameThreadJoin(self, ) -> bool:
        pass

    def overrideThread(self, ) -> Thread:
        pass

    def andThen(self, after: Function, ) -> self:
        pass

    def negate(self, ) -> self:
        pass


    pass
