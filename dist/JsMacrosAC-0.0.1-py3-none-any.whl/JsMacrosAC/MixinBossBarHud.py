from .IBossBarHud import *

class MixinBossBarHud(Object, IBossBarHud):



    def __init__():
        pass


    def jsmacros_GetBossBars(self, ) -> list:
        pass


    pass
