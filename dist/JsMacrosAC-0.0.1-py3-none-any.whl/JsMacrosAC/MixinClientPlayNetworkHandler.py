
class MixinClientPlayNetworkHandler(Object, ):



    def __init__():
        pass


    def onServerTime(self, packet: WorldTimeUpdateS2CPacket, info: CallbackInfo, ) -> None:
        pass

    def onGameJoin(self, packet: GameJoinS2CPacket, info: CallbackInfo, ) -> None:
        pass


    pass
