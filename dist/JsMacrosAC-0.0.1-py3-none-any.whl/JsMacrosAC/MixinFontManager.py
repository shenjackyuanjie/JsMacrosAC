from .IFontManager import *

class MixinFontManager(Object, IFontManager):



    def __init__():
        pass


    def getFontList(self, ) -> list:
        pass


    pass
