
class MixinGameRenderer(Object, ):



    def __init__():
        pass


    def render(self, tickDelta: float, limitTime: long, matrix: MatrixStack, info: CallbackInfo, ) -> None:
        pass


    pass
