from .IHorseScreen import *

class MixinHorseScreen(Object, IHorseScreen):



    def __init__():
        pass


    def jsmacros_getEntity(self, ) -> Entity:
        pass


    pass
