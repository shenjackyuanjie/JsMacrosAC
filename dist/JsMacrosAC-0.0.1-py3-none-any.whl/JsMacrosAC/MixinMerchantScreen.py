from .IMerchantScreen import *

class MixinMerchantScreen(Object, IMerchantScreen):



    def __init__():
        pass


    def selectIndex(self, index: int, ) -> None:
        pass


    pass
