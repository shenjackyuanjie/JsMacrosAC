from .IPlayerListHud import *

class MixinPlayerListHud(Object, IPlayerListHud):



    def __init__():
        pass


    def jsmacros_getHeader(self, ) -> str:
        pass

    def jsmacros_getFooter(self, ) -> str:
        pass


    pass
