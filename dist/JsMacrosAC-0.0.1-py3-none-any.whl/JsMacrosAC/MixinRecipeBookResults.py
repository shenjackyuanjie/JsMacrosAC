from .IRecipeBookResults import *

class MixinRecipeBookResults(Object, IRecipeBookResults):



    def __init__():
        pass


    def getResultCollections(self, ) -> list:
        pass


    pass
