from .IRecipeBookWidget import *

class MixinRecipeBookWidget(Object, IRecipeBookWidget):



    def __init__():
        pass


    def jsmacros_getResults(self, ) -> RecipeBookResults:
        pass

    def jsmacros_isSearching(self, ) -> bool:
        pass

    def jsmacros_refreshResultList(self, ) -> None:
        pass


    pass
