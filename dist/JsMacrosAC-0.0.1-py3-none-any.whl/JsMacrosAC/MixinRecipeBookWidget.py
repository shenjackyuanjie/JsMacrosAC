from .IRecipeBookWidget import *

class MixinRecipeBookWidget(Object, IRecipeBookWidget):



    def __init__():
        pass


    def getResults(self, ) -> RecipeBookResults:
        pass

    def isSearching(self, ) -> bool:
        pass

    def refreshResultList(self, ) -> None:
        pass


    pass
