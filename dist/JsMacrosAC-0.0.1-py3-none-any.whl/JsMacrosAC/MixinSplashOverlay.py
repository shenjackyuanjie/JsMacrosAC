
class MixinSplashOverlay(Object, ):



    def __init__():
        pass



    pass
