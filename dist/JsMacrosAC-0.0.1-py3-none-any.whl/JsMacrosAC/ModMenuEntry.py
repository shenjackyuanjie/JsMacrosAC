
class ModMenuEntry(Object, ModMenuApi):



    def __init__():
        pass


    def getModConfigScreenFactory(self, ) -> ConfigScreenFactory:
        pass


    pass
