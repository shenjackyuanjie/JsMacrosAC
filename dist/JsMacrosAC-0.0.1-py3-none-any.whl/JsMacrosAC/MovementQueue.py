from .PlayerInput import *
from .Draw3D import *

class MovementQueue(Object, ):

    predPoints: Draw3D = None


    def __init__():
        pass


    def tick(self, newPlayer: ClientPlayerEntity, ) -> PlayerInput:
        pass

    def append(self, input: PlayerInput, newPlayer: ClientPlayerEntity, ) -> None:
        pass

    def clear(self, ) -> None:
        pass


    pass
