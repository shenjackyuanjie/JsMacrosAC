from .NBTElementHelper import *
from .NBTElementHelper import *

class NBTCompoundHelper(NBTElementHelper, ):



    def getType(self, key: str, ) -> int:
        pass

    def has(self, key: str, ) -> bool:
        pass

    def get(self, key: str, ) -> NBTElementHelper:
        pass

    def asString(self, key: str, ) -> str:
        pass


    pass
