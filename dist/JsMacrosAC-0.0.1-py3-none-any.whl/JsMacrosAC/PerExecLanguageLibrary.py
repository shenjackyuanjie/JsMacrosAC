from .ContextContainer import *
from .BaseLibrary import *

class PerExecLanguageLibrary(BaseLibrary, ):



    def __init__(context: ContextContainer, language: Class, ):
        pass



    pass
