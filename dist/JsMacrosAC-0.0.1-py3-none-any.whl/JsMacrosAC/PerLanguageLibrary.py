from .BaseLibrary import *

class PerLanguageLibrary(BaseLibrary, ):



    def __init__(language: Class, ):
        pass



    pass
