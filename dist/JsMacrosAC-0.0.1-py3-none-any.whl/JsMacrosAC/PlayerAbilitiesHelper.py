from .BaseHelper import *

class PlayerAbilitiesHelper(BaseHelper, ):



    def __init__(a: PlayerAbilities, ):
        pass


    def getInvulnerable(self, ) -> bool:
        pass

    def getFlying(self, ) -> bool:
        pass

    def getAllowFlying(self, ) -> bool:
        pass

    def getCreativeMode(self, ) -> bool:
        pass

    def setFlying(self, b: bool, ) -> self:
        pass

    def setAllowFlying(self, b: bool, ) -> self:
        pass

    def getFlySpeed(self, ) -> float:
        pass

    def setFlySpeed(self, flySpeed: float, ) -> self:
        pass


    pass
