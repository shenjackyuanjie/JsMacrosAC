from .Vec2D import *
from .Pos3D import *

class Pos2D(Object, ):

    ZERO: self = None
    x: float = None
    y: float = None


    def __init__(x: float, y: float, ):
        pass


    def getX(self, ) -> float:
        pass

    def getY(self, ) -> float:
        pass

    def add(self, pos: self, ) -> self:
        pass

    def multiply(self, pos: self, ) -> self:
        pass

    def toString(self, ) -> str:
        pass

    def to3D(self, ) -> Pos3D:
        pass

    def toVector(self, ) -> Vec2D:
        pass


    pass
