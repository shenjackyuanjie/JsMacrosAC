
class Prism(Object, GrammarLocator):



    def __init__():
        pass


    def getNodes(self, text: str, language: str, ) -> list:
        pass

    def grammar(self, prism4j: Prism4j, language: str, ) -> Grammar:
        pass

    def languages(self, ) -> list:
        pass


    pass
