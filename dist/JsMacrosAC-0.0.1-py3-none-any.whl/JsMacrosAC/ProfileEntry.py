from .MapSettingEntry import *
from .ProfileSetting import *

class ProfileEntry(MapSettingEntry, ):



    def __init__(x: int, y: int, width: int, textRenderer: TextRenderer, parent: ProfileSetting, key: str, value: list, ):
        pass


    def init(self, ) -> None:
        pass


    pass
