from .TextHelper import *
from .BaseHelper import *

class ScoreboardObjectiveHelper(BaseHelper, ):



    def __init__(o: ScoreboardObjective, ):
        pass


    def getPlayerScores(self, ) -> list:
        pass

    def getName(self, ) -> str:
        pass

    def getDisplayName(self, ) -> TextHelper:
        pass


    pass
