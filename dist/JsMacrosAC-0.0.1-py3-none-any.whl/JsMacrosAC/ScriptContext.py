
class ScriptContext(Object, ):

    startTime: long = None


    def __init__():
        pass


    def getContext(self, ) -> WeakReference:
        pass

    def setContext(self, context: T, ) -> None:
        pass

    def isContextClosed(self, ) -> bool:
        pass

    def closeContext(self, ) -> None:
        pass


    pass
