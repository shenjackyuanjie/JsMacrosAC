from .HistoryStep import *

class ShiftLine(History$HistoryStep, ):




    pass
