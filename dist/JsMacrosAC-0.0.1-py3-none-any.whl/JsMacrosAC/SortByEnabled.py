from .ScriptTrigger import *

class SortByEnabled(Object, Comparator):



    def __init__():
        pass


    def compare(self, a: ScriptTrigger, b: ScriptTrigger, ) -> int:
        pass


    pass
