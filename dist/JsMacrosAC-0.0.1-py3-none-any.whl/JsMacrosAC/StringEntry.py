from .StringMapSetting import *
from .MapSettingEntry import *

class StringEntry(AbstractMapSettingContainer$MapSettingEntry, ):



    def __init__(x: int, y: int, width: int, textRenderer: TextRenderer, parent: StringMapSetting, key: str, value: str, ):
        pass


    def init(self, ) -> None:
        pass


    pass
