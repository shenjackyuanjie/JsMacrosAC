from .MapSettingEntry import *
from .StringMapSetting import *

class StringEntry(MapSettingEntry, ):



    def __init__(x: int, y: int, width: int, textRenderer: TextRenderer, parent: StringMapSetting, key: str, value: str, ):
        pass


    def init(self, ) -> None:
        pass


    pass
