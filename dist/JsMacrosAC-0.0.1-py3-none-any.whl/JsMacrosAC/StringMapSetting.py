from .SettingsOverlay import *
from .AbstractMapSettingContainer import *

class StringMapSetting(AbstractMapSettingContainer, ):



    def __init__(x: int, y: int, width: int, height: int, textRenderer: TextRenderer, parent: SettingsOverlay, group: str, ):
        pass


    def addField(self, key: str, value: str, ) -> None:
        pass


    pass
