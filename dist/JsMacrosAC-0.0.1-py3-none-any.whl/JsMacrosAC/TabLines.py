from .HistoryStep import *
from .SelectCursor import *

class TabLines(History$HistoryStep, ):



    def __init__(startLine: int, lineCount: int, reversed: bool, cursor: SelectCursor, ):
        pass



    pass
