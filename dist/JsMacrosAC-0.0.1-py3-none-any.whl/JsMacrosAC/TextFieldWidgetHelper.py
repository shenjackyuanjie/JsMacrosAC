from .ButtonWidgetHelper import *

class TextFieldWidgetHelper(ButtonWidgetHelper, ):



    def __init__(t: TextFieldWidget, ):
        pass


    def getText(self, ) -> str:
        pass

    def setText(self, text: str, ) -> self:
        pass

    def setText(self, text: str, await: bool, ) -> self:
        pass

    def setEditableColor(self, color: int, ) -> self:
        pass

    def setEditable(self, edit: bool, ) -> self:
        pass

    def setUneditableColor(self, color: int, ) -> self:
        pass


    pass
