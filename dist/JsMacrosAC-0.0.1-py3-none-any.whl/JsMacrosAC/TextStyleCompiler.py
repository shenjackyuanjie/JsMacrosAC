
class TextStyleCompiler(AbsVisitor, ):



    def __init__(defaultStyle: Style, themeData: list, ):
        pass


    def getResult(self, ) -> list:
        pass


    pass
