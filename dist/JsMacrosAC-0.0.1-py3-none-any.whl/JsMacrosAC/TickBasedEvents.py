
class TickBasedEvents(Object, ):



    def __init__():
        pass


    def areNotEqual(self, a: ItemStack, b: ItemStack, ) -> bool:
        pass

    def areTagsEqualIgnoreDamage(self, a: ItemStack, b: ItemStack, ) -> bool:
        pass

    def areEqualIgnoreDamage(self, a: ItemStack, b: ItemStack, ) -> bool:
        pass

    def init(self, ) -> None:
        pass


    pass
