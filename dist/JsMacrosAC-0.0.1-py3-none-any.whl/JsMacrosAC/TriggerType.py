
class TriggerType(Enum, ):

    KEY_FALLING: self = None
    KEY_RISING: self = None
    KEY_BOTH: self = None
    EVENT: self = None


    def values(self, ) -> self:
        pass

    def valueOf(self, name: str, ) -> self:
        pass


    pass
