
class WrappedThread(Object, ):

    thread: Thread = None
    notDone: bool = None


    def __init__(thread: Thread, notDone: bool, ):
        pass


    def waitFor(self, ) -> None:
        pass

    def release(self, ) -> None:
        pass


    pass
