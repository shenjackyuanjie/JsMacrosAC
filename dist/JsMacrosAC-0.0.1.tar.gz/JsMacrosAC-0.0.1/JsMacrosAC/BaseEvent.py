from .BaseProfile import *

class BaseEvent(none, ):

    profile: BaseProfile = None


    def getEventName(self, ) -> str:
        pass


    pass
