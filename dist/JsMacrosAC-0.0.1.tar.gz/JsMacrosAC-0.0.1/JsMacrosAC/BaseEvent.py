from .BaseProfile import *

class BaseEvent():

    profile: BaseProfile = None


    def getEventName(self, ) -> str:
        pass


    pass
