
class BaseHelper(Object, ):



    def __init__(base: T, ):
        pass


    def getRaw(self, ) -> T:
        pass


    pass
