from .Inventory import *

class BeaconInventory(Inventory, ):



    def getLevel(self, ) -> int:
        pass

    def getFirstEffect(self, ) -> str:
        pass

    def getSecondEffect(self, ) -> str:
        pass

    def selectFirstEffect(self, id: str, ) -> bool:
        pass

    def selectSecondEffect(self, id: str, ) -> bool:
        pass

    def applyEffects(self, ) -> bool:
        pass


    pass
