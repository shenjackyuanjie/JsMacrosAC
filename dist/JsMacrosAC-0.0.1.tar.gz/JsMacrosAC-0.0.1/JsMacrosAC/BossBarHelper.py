from .TextHelper import *
from .BaseHelper import *

class BossBarHelper(BaseHelper, ):



    def __init__(b: BossBar, ):
        pass


    def getUUID(self, ) -> str:
        pass

    def getPercent(self, ) -> float:
        pass

    def getColor(self, ) -> str:
        pass

    def getStyle(self, ) -> str:
        pass

    def getName(self, ) -> TextHelper:
        pass

    def toString(self, ) -> str:
        pass


    pass
