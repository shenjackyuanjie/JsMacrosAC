
class ClassData(Object, ):

    methods: list = None
    fields: list = None
    name: str = None


    def __init__(name: str, ):
        pass


    def toString(self, ) -> str:
        pass


    pass
