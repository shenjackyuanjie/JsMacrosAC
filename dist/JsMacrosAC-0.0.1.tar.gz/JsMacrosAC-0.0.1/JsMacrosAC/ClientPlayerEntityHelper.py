from .PlayerEntityHelper import *

class ClientPlayerEntityHelper(PlayerEntityHelper, ):



    def __init__(e: T, ):
        pass


    def lookAt(self, yaw: float, pitch: float, ) -> self:
        pass

    def lookAt(self, x: float, y: float, z: float, ) -> self:
        pass

    def getFoodLevel(self, ) -> int:
        pass

    def toString(self, ) -> str:
        pass


    pass
