
class CombinedVariableClassLoader(ClassLoader, ):



    def __init__(parent: ClassLoader, ):
        pass


    def addClassLoader(self, jarPath: File, loader: ClassLoader, ) -> bool:
        pass

    def hasJar(self, path: File, ) -> bool:
        pass


    pass
