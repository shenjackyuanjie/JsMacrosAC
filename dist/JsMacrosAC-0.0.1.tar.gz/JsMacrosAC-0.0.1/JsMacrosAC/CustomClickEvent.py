
class CustomClickEvent(ClickEvent, ):



    def __init__(event: Runnable, ):
        pass


    def hashCode(self, ) -> int:
        pass

    def getEvent(self, ) -> Runnable:
        pass


    pass
