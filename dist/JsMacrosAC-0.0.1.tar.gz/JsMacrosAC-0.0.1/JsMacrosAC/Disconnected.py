
class Disconnected(Object, ):

    serverFrame: WebSocketFrame = None
    clientFrame: WebSocketFrame = None
    isServer: bool = None


    def __init__(serverFrame: WebSocketFrame, clientFrame: WebSocketFrame, isServer: bool, ):
        pass



    pass
