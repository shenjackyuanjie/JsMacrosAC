from .BaseEvent import *

class EventAirChange(Object, BaseEvent):

    air: int = None


    def __init__(air: int, ):
        pass


    def toString(self, ) -> str:
        pass


    pass
