from .BaseEvent import *

class EventHungerChange(Object, BaseEvent):

    foodLevel: int = None


    def __init__(foodLevel: int, ):
        pass


    def toString(self, ) -> str:
        pass


    pass
