from .BaseEvent import *

class EventJoinedTick(Object, BaseEvent):



    def __init__():
        pass


    def toString(self, ) -> str:
        pass


    pass
