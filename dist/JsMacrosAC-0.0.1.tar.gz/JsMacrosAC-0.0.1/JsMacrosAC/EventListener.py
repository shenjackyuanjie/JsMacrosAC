from .ScriptTrigger import *
from .Core import *
from .BaseListener import *
from .ContextContainer import *
from .BaseEvent import *

class EventListener(BaseListener, ):



    def __init__(macro: ScriptTrigger, runner: Core, ):
        pass


    def trigger(self, event: BaseEvent, ) -> ContextContainer:
        pass


    pass
