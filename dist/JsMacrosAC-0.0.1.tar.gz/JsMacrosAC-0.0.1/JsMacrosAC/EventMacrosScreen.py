from .MacroScreen import *

class EventMacrosScreen(MacroScreen, ):



    def __init__(parent: Screen, ):
        pass



    pass
