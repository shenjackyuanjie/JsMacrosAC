from .BaseEvent import *

class EventSendMessage(Object, BaseEvent):

    message: str = None


    def __init__(message: str, ):
        pass


    def toString(self, ) -> str:
        pass


    pass
