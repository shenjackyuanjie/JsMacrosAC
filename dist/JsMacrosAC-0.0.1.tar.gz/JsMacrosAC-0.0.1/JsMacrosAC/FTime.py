from .BaseLibrary import *

class FTime(BaseLibrary, ):



    def time(self, ) -> long:
        pass

    def sleep(self, millis: long, ) -> None:
        pass


    pass
