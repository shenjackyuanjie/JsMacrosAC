from .FileMapSetting import *
from .MapSettingEntry import *

class FileEntry(AbstractMapSettingContainer$MapSettingEntry, ):



    def __init__(x: int, y: int, width: int, textRenderer: TextRenderer, parent: FileMapSetting, key: str, value: str, ):
        pass


    def init(self, ) -> None:
        pass


    pass
