from .SourceLocation import *

class HostLocation(SourceLocation, ):

    location: str = None


    def __init__(location: str, ):
        pass


    def toString(self, ) -> str:
        pass


    pass
