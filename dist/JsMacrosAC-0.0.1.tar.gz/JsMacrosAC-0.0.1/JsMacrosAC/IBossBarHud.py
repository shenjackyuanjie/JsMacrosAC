
class IBossBarHud(none, ):



    def jsmacros_GetBossBars(self, ) -> list:
        pass


    pass
