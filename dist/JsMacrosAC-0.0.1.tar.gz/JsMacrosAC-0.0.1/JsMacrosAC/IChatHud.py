
class IChatHud():



    def jsmacros_addMessageBypass(self, message: str, ) -> None:
        pass


    pass
