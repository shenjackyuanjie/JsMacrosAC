from .BaseEvent import *
from .ContextContainer import *

class IEventListener():



    def trigger(self, event: BaseEvent, ) -> ContextContainer:
        pass


    pass
