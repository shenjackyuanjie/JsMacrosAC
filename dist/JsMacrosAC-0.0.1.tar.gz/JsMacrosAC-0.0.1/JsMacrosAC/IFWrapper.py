from .MethodWrapper import *

class IFWrapper(none, ):



    def methodToJava(self, c: T, ) -> MethodWrapper:
        pass

    def methodToJavaAsync(self, c: T, ) -> MethodWrapper:
        pass

    def stop(self, ) -> None:
        pass


    pass
