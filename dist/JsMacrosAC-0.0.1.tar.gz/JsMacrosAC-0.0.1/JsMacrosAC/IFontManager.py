
class IFontManager(none, ):



    def jsmacros_getFontList(self, ) -> list:
        pass


    pass
