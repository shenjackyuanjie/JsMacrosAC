
class IHorseScreen(none, ):



    def jsmacros_getEntity(self, ) -> Entity:
        pass


    pass
