
class IMerchantScreen():



    def selectIndex(self, index: int, ) -> None:
        pass


    pass
