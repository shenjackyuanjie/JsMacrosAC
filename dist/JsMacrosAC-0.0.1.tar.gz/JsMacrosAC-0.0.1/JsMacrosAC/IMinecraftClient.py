
class IMinecraftClient(none, ):



    def jsmacros_getFontManager(self, ) -> FontManager:
        pass

    def jsmacros_doItemUse(self, ) -> None:
        pass

    def jsmacros_doAttack(self, ) -> None:
        pass


    pass
