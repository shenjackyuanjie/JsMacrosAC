
class IRecipeBookResults(none, ):



    def jsmacros_getResultCollections(self, ) -> list:
        pass


    pass
