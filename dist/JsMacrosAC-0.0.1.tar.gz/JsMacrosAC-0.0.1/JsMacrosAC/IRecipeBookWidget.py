
class IRecipeBookWidget(none, ):



    def jsmacros_getResults(self, ) -> RecipeBookResults:
        pass

    def jsmacros_isSearching(self, ) -> bool:
        pass

    def jsmacros_refreshResultList(self, ) -> None:
        pass


    pass
