from .BaseEvent import *
from .ScriptContext import *

class JSScriptContext(ScriptContext, ):



    def __init__(event: BaseEvent, ):
        pass


    def isContextClosed(self, ) -> bool:
        pass

    def closeContext(self, ) -> None:
        pass


    pass
