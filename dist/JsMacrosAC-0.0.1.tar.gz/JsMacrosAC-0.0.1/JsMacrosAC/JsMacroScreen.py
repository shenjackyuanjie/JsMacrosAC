from .BaseScreen import *

class JsMacroScreen(Object, ConfigScreenFactory):



    def __init__():
        pass


    def create(self, parent: Screen, ) -> BaseScreen:
        pass


    pass
