from .MacroScreen import *

class KeyMacrosScreen(MacroScreen, ):



    def __init__(parent: Screen, ):
        pass


    def init(self, ) -> None:
        pass

    def keyReleased(self, keyCode: int, scanCode: int, modifiers: int, ) -> bool:
        pass

    def mouseReleased(self, mouseX: float, mouseY: float, button: int, ) -> bool:
        pass


    pass
