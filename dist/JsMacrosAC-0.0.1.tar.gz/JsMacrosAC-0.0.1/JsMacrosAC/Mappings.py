
class Mappings(Object, ):

    mappingsource: str = None
    intMappings: list = None
    namedMappings: list = None


    def __init__(mappingsource: str, ):
        pass


    def reverseMappings(self, ) -> None:
        pass

    def getMappings(self, ) -> list:
        pass

    def getReversedMappings(self, ) -> list:
        pass


    pass
