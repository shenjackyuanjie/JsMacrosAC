from .LivingEntityHelper import *

class MerchantEntityHelper(LivingEntityHelper, ):



    def __init__(e: MerchantEntity, ):
        pass


    def getTrades(self, ) -> list:
        pass

    def getExperience(self, ) -> int:
        pass

    def hasCustomer(self, ) -> bool:
        pass


    pass
