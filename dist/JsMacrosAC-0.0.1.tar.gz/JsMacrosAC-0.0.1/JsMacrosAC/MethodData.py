
class MethodData(Object, ):

    name: str = None
    sig: str = None


    def __init__(name: str, sig: str, ):
        pass


    def toString(self, ) -> str:
        pass


    pass
