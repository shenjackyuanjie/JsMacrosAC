from .IBeaconScreen import *

class MixinBeaconScreen(Object, IBeaconScreen):



    def __init__():
        pass


    def jsmacros_getPrimaryEffect(self, ) -> StatusEffect:
        pass

    def jsmacros_setPrimaryEffect(self, effect: StatusEffect, ) -> None:
        pass

    def jsmacros_getSecondaryEffect(self, ) -> StatusEffect:
        pass

    def jsmacros_setSecondaryEffect(self, effect: StatusEffect, ) -> None:
        pass


    pass
