from .IChatHud import *

class MixinChatHud(Object, IChatHud):



    def __init__():
        pass


    def jsmacros_addMessageBypass(self, message: str, ) -> None:
        pass


    pass
