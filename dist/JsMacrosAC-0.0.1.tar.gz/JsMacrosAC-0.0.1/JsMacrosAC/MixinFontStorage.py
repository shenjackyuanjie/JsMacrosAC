
class MixinFontStorage(Object, ):



    def __init__():
        pass



    pass
