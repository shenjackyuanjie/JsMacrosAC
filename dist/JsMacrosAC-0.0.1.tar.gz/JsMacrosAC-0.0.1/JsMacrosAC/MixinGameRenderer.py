
class MixinGameRenderer(Object, ):



    def __init__():
        pass


    def render(self, info: CallbackInfo, ) -> None:
        pass


    pass
