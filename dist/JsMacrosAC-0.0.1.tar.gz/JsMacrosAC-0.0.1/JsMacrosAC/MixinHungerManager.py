
class MixinHungerManager(Object, ):



    def __init__():
        pass


    def onSetFoodLevel(self, foodLevel: int, info: CallbackInfo, ) -> None:
        pass


    pass
