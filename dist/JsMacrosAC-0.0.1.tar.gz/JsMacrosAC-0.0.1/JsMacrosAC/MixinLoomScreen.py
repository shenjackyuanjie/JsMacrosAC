from .ILoomScreen import *

class MixinLoomScreen(Object, ILoomScreen):



    def __init__():
        pass


    def jsmacros_canApplyDyePattern(self, ) -> bool:
        pass


    pass
