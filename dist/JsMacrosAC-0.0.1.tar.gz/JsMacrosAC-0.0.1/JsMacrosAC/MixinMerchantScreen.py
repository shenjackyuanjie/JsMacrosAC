from .IMerchantScreen import *

class MixinMerchantScreen(Object, IMerchantScreen):



    def __init__():
        pass


    def jsmacros_selectIndex(self, index: int, ) -> None:
        pass


    pass
