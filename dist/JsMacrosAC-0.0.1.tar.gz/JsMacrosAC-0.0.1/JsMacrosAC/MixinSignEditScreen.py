from .ISignEditScreen import *

class MixinSignEditScreen(Object, ISignEditScreen):



    def __init__():
        pass


    def jsmacros_setLine(self, line: int, text: str, ) -> None:
        pass


    pass
