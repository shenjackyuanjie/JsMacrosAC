
class MixinSoundSystem(Object, ):



    def __init__():
        pass


    def onPlay(self, instance: SoundInstance, info: CallbackInfo, ) -> None:
        pass


    pass
