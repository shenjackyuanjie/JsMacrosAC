
class MixinTrueTypeFont(Object, ):



    def __init__():
        pass


    def modifyWidth(self, w: int, i: int, ) -> int:
        pass

    def modifyHeight(self, h: int, i: int, ) -> int:
        pass


    pass
