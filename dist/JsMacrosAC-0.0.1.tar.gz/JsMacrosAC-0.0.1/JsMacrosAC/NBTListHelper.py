from .NBTElementHelper import *
from .NBTElementHelper import *

class NBTListHelper(NBTElementHelper, ):



    def get(self, index: int, ) -> NBTElementHelper:
        pass

    def getHeldType(self, ) -> int:
        pass


    pass
