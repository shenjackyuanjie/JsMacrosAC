from .NBTElementHelper import *

class NBTNumberHelper(NBTElementHelper, ):



    def asLong(self, ) -> long:
        pass

    def asInt(self, ) -> int:
        pass

    def asShort(self, ) -> short:
        pass

    def asByte(self, ) -> byte:
        pass

    def asFloat(self, ) -> float:
        pass

    def asDouble(self, ) -> float:
        pass

    def asNumber(self, ) -> Number:
        pass


    pass
