from .OptionType import *

class Option(none, Annotation):



    def translationKey(self, ) -> str:
        pass

    def group(self, ) -> str:
        pass

    def setter(self, ) -> str:
        pass

    def getter(self, ) -> str:
        pass

    def options(self, ) -> str:
        pass

    def type(self, ) -> OptionType:
        pass


    pass
