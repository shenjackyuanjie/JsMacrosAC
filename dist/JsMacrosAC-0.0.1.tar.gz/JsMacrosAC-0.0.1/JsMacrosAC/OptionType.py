
class OptionType(none, Annotation):



    def value(self, ) -> str:
        pass

    def options(self, ) -> str:
        pass


    pass
