
class Pair(Object, ):



    def __init__(t: T, u: U, ):
        pass


    def setU(self, u: U, ) -> None:
        pass

    def setT(self, t: T, ) -> None:
        pass

    def getU(self, ) -> U:
        pass

    def getT(self, ) -> T:
        pass


    pass
