from .TextHelper import *
from .BaseHelper import *

class PlayerListEntryHelper(BaseHelper, ):



    def __init__(p: PlayerListEntry, ):
        pass


    def getUUID(self, ) -> str:
        pass

    def getName(self, ) -> str:
        pass

    def getDisplayText(self, ) -> TextHelper:
        pass

    def toString(self, ) -> str:
        pass


    pass
