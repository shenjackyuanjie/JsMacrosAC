from .Pos2D import *
from .Vec3D import *

class Pos3D(PositionCommon$Pos2D, ):

    ZERO: self = None
    z: float = None


    def __init__(vec: Vec3d, ):
        pass


    def getZ(self, ) -> float:
        pass

    def add(self, pos: self, ) -> self:
        pass

    def multiply(self, pos: self, ) -> self:
        pass

    def toString(self, ) -> str:
        pass

    def toVector(self, ) -> Vec3D:
        pass


    pass
