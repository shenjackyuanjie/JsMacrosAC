from .ProfileSetting import *
from .MapSettingEntry import *

class ProfileEntry(AbstractMapSettingContainer$MapSettingEntry, ):



    def __init__(x: int, y: int, width: int, textRenderer: TextRenderer, parent: ProfileSetting, key: str, value: list, ):
        pass


    def init(self, ) -> None:
        pass


    pass
