from .RunningContextContainer import *

class RTCSort(Object, Comparator):



    def __init__():
        pass


    def compare(self, arg0: RunningContextContainer, arg1: RunningContextContainer, ) -> int:
        pass


    pass
