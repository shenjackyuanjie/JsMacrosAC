from .ItemStackHelper import *
from .BaseHelper import *

class RecipeHelper(BaseHelper, ):



    def __init__(base: Recipe, syncId: int, ):
        pass


    def getId(self, ) -> str:
        pass

    def getOutput(self, ) -> ItemStackHelper:
        pass

    def craft(self, craftAll: bool, ) -> None:
        pass

    def toString(self, ) -> str:
        pass


    pass
