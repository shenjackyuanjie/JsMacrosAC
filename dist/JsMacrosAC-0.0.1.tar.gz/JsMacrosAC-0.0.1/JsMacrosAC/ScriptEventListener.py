from .IEventListener import *
from .MethodWrapper import *

class ScriptEventListener(none, IEventListener):



    def getCreator(self, ) -> Thread:
        pass

    def getWrapper(self, ) -> MethodWrapper:
        pass


    pass
