from .MethodWrapper import *

class ScriptEventListener():



    def getCreator(self, ) -> Thread:
        pass

    def getWrapper(self, ) -> MethodWrapper:
        pass


    pass
