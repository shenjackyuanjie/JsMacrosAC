from .BaseLanguage import *

class SortLanguage(Object, Comparator):



    def __init__():
        pass


    def compare(self, a: BaseLanguage, b: BaseLanguage, ) -> int:
        pass


    pass
