from .BaseHelper import *

class StatusEffectHelper(BaseHelper, ):



    def __init__(s: StatusEffectInstance, ):
        pass


    def getId(self, ) -> str:
        pass

    def getStrength(self, ) -> int:
        pass

    def getTime(self, ) -> int:
        pass


    pass
