
class TPSData(Object, ):

    recvTime: long = None
    tps: float = None


    def __init__(time: long, tps: float, ):
        pass



    pass
