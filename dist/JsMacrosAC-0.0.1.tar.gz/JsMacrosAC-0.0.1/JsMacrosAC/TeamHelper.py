from .TextHelper import *
from .BaseHelper import *

class TeamHelper(BaseHelper, ):



    def __init__(t: Team, ):
        pass


    def getName(self, ) -> str:
        pass

    def getDisplayName(self, ) -> TextHelper:
        pass

    def getPlayerList(self, ) -> list:
        pass

    def getColor(self, ) -> int:
        pass

    def getPrefix(self, ) -> TextHelper:
        pass

    def getSuffix(self, ) -> TextHelper:
        pass

    def getCollisionRule(self, ) -> str:
        pass

    def isFriendlyFire(self, ) -> bool:
        pass

    def showFriendlyInvisibles(self, ) -> bool:
        pass

    def nametagVisibility(self, ) -> str:
        pass

    def deathMessageVisibility(self, ) -> str:
        pass

    def toString(self, ) -> str:
        pass


    pass
