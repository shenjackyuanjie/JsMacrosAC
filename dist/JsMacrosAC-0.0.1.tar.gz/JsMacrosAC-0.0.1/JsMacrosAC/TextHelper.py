from .BaseHelper import *

class TextHelper(BaseHelper, ):



    def __init__(json: str, ):
        pass


    def replaceFromJson(self, json: str, ) -> self:
        pass

    def replaceFromString(self, content: str, ) -> self:
        pass

    def getJson(self, ) -> str:
        pass

    def getString(self, ) -> str:
        pass

    def toJson(self, ) -> str:
        pass

    def toString(self, ) -> str:
        pass


    pass
