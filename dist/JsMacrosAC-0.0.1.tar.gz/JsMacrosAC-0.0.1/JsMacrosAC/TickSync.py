
class TickSync(Object, ):



    def __init__():
        pass


    def waitTick(self, ) -> None:
        pass

    def tick(self, ) -> None:
        pass


    pass
