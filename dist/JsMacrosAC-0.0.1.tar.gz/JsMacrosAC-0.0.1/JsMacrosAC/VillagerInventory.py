from .Inventory import *

class VillagerInventory(Inventory, ):



    def selectTrade(self, index: int, ) -> self:
        pass

    def getExperience(self, ) -> int:
        pass

    def getLevelProgress(self, ) -> int:
        pass

    def getMerchantRewardedExperience(self, ) -> int:
        pass

    def canRefreshTrades(self, ) -> bool:
        pass

    def isLeveled(self, ) -> bool:
        pass

    def getTrades(self, ) -> list:
        pass


    pass
