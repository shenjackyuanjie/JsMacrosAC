from .Button import *

class fileObj(Object, ):

    file: File = None
    btn: Button = None


    def __init__(file: File, btn: Button, ):
        pass



    pass
