
class sortFile(Object, Comparator):



    def __init__():
        pass


    def compare(self, a: File, b: File, ) -> int:
        pass


    pass
