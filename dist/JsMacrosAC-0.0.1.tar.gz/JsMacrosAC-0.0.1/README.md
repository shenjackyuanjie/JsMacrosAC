# JsMacrosAC
 
This package is currently under development so there can be some minor bugs!

The only purpose of this package is to let your IDE know, what functions the different [JsMacros](https://www.curseforge.com/minecraft/mc-mods/jsmacros) Classes have.\
Please note that this package does not add **ANY** functionality and will crash your scripts if not imported properly.

# How to Import
```python
if __name__ == "": from JsMacrosAC import *
```

Because Python does not support function overloading, in some IDE's only one function will show up. The description of the function will tell you what different ways there are to use this function.
